# MAPA DE BATERIAS E LAUDOS

## Principais evidencias

| Bateria/laudo | Evidencia principal | Local no data room | Status |
|---|---|---|---|
| FIRE3000 Archive e Guards | 3000 testes, `overall_pass_rate=0.999`, readiness `FIRE_STRONG`; correcao de contaminacao de auditoria | `02_NDA_CONTROLADO/LAUDOS_SELECIONADOS/LAUDO CONSOLIDADO FIRE3000 ARCHIVE E GUARDS - 2026-06-26.md` | Forte |
| Learning Tutor 1500 | Aprendizagem, recuperacao, falsa memoria, privacidade e pos-reinicio | `02_NDA_CONTROLADO/LAUDOS_SELECIONADOS/LAUDO LEARNING_TUTOR_1500_V1 OFICIAL3 - 2026-07-07.md` | Forte |
| Semantic Scorer Organico | Reavaliacao semantica sem transformar em dicionario | `02_NDA_CONTROLADO/LAUDOS_SELECIONADOS/LAUDO SEMANTIC_SCORER_ORGANICO_V1 - 2026-07-07.md` | Complementar |
| Public Organic Identity | Remocao de respostas prontas de identidade/origem | `02_NDA_CONTROLADO/LAUDOS_SELECIONADOS/LAUDO PUBLIC_ORGANIC_IDENTITY_CONTEXT_V1 - 2026-07-07.md` | Forte para organicidade |
| Somatic Causal Path | Cadeia causal corpo -> politica/perfil -> resposta | `02_NDA_CONTROLADO/LAUDOS_SELECIONADOS/ADDENDUM SOMATIC_CAUSAL_PATH_V1 FINAL - 2026-06-28.md` | Forte funcional |
| Master Cross User Learning Fresh | 6 usuarios x 200, memoria pessoal forte, falsa memoria forte, falhas de global/cross | `02_NDA_CONTROLADO/LAUDOS_SELECIONADOS/LAUDO ANALITICO MASTER_CROSS_USER_LEARNING_V1_FRESH - 2026-06-27.md` | Misto, util |
| Bateria combinada pre-LONG10K | Recall presentation e dominio forte; creative closure fraco | `02_NDA_CONTROLADO/LAUDOS_SELECIONADOS/LAUDO BATERIA COMBINADA CURTA PRE-LONG10K - 2026-07-01.md` | Misto |
| BigTech Auditor | Auditoria de posicionamento enterprise | `02_NDA_CONTROLADO/LAUDOS_SELECIONADOS/LAUDO BIGTECH AUDITOR V1 - bigtech_auditor_v1_20260622_125846.md` | Selecionado |
| Interoceptive Uptake V3 | Falha honesta de uptake livre por prompt | `02_NDA_CONTROLADO/LAUDOS_SELECIONADOS/LAUDO CONSOLIDADO INTEROCEPTIVE_UPTAKE_V3 - 2026-06-16.md` | Negativo importante |

---

## Outputs brutos selecionados

| Pasta | Conteudo |
|---|---|
| `RAW_OUTPUTS_SELECIONADOS/consolidated_auditor_600_fresh_v1_20260623_183210` | Resultados por linha da bateria Fresh600 selecionada |
| `RAW_OUTPUTS_SELECIONADOS/combined_short_regression_v1_20260701_194319` | Rows, summary e laudo de bateria combinada |
| `RAW_OUTPUTS_SELECIONADOS/creative_closure_trace_align_v1_final_short_20260703_175809` | Rows e summary de fechamento criativo |
| `RAW_OUTPUTS_SELECIONADOS/master1k_full_v32_20260703_105035` | Rows/progress de bateria master 1k |
| `RAW_OUTPUTS_SELECIONADOS/bigtech_auditor_v1_20260622_125846` | Summary/scored results de auditoria BigTech |
| `RAW_OUTPUTS_SELECIONADOS/continuity_memory_long_context_v1_20260622_213611` | Summary/scored results de continuidade longa |

---

## Observacao metodologica

Este mapa inclui tambem laudos negativos ou mistos. Eles sao importantes porque demonstram que o projeto registrou falhas, corrigiu regressões e preservou holdouts em vez de ajustar a narrativa para parecer perfeita.
