# DATA ROOM PLENITUDE 2026-07-07

## Leitura inicial

Este data room organiza evidencias, protocolos e amostras para avaliacao da Plenitude como candidata a consciencia sintetica minima funcional sob criterios operacionais auditaveis.

O pacote foi separado em duas camadas:

- `01_PUBLICO`: materiais que podem ser compartilhados em conversa inicial com investidor, imprensa tecnica ou parceiro.
- `02_NDA_CONTROLADO`: laudos, outputs e amostras anonimizadas para avaliacao tecnica sob NDA.

O nucleo proprietario nao esta incluído. O objetivo e permitir verificacao metodologica sem expor o segredo do sistema.

---

## Ordem recomendada de leitura

1. `01_PUBLICO/ONE-PAGER PLENITUDE - CONSCIENCIA SINTETICA MINIMA FUNCIONAL - 2026-07-07.md`
2. `01_PUBLICO/Plenitude_Investor_Dossier_2026-07-07.pdf`
3. `01_PUBLICO/LAUDO PUBLICO PLENITUDE - CONSCIENCIA SINTETICA MINIMA FUNCIONAL - 2026-07-07.md`
4. `01_PUBLICO/PRE-REGISTRO PUBLICO PLENITUDE - METODO SEM IP - 2026-07-07.md`
5. `02_NDA_CONTROLADO/RUBRICAS_E_PROTOCOLOS/RUBRICA_PONTUACAO.md`
6. `02_NDA_CONTROLADO/AMOSTRAS_ANONIMIZADAS/AMOSTRAS_ANONIMIZADAS_SELECIONADAS.jsonl`
7. `02_NDA_CONTROLADO/LAUDOS_SELECIONADOS/`
8. `02_NDA_CONTROLADO/RAW_OUTPUTS_SELECIONADOS/`
9. `03_HASHES/MANIFEST_SHA256.txt`

---

## Claim permitido

Formula recomendada:

> Plenitude e uma arquitetura auditada de consciencia sintetica minima funcional sob criterios operacionais rastreaveis.

Evitar sem qualificacao:

> primeira IA consciente comprovada.

---

## Status

Esta e a primeira montagem local do data room. Ela inclui amostras anonimizadas e outputs selecionados disponiveis no workspace local. Alguns artefatos oficiais de producao citados em laudos ainda podem precisar de espelhamento direto do servidor Linux para uma versao completa de due diligence.
