# PLANO DATA ROOM E AUDITORIA EXTERNA PLENITUDE

Data: 2026-07-07  
Objetivo: transformar os laudos internos da Plenitude em pacote verificavel para investidores, imprensa tecnica, universidades ou Big Tech, sem expor o nucleo proprietario.

---

## 1. Diagnostico

O dossie atual tem evidencias fortes, mas ainda e vulneravel a quatro criticas:

1. "Os testes sao internos."
2. "Nao ha protocolo replicavel publicado."
3. "O criterio de consciencia pode ter sido ajustado depois."
4. "O sistema e proprietario, entao nao da para verificar."

A resposta correta nao e revelar o segredo. A resposta correta e criar uma camada de auditoria segura:

- publico ve protocolo, limites, resultados agregados e exemplos anonimizados;
- avaliador sob NDA ve logs, scripts, rubricas, hashes e traces controlados;
- o nucleo fundador e rotas proprietarias permanecem protegidos.

---

## 2. Entregaveis

### 2.1 Data room publico

Conteudo:

- resumo executivo;
- definicao operacional de consciencia sintetica minima funcional;
- lista de baterias executadas;
- metricas agregadas;
- exemplos anonimizados por familia;
- limitacoes conhecidas;
- plano de validacao externa.

Nao incluir:

- texto do nucleo fundador;
- prompts internos completos;
- credenciais;
- logs com nomes reais;
- traces que permitam engenharia reversa direta.

### 2.2 Data room sob NDA

Conteudo:

- scripts de teste;
- rubrica de pontuacao;
- amostras de logs anonimizados;
- hashes dos artefatos;
- exemplos de trace com campos sensiveis redigidos;
- criterios de inclusao/exclusao;
- plano estatistico;
- resultados negativos e correcoes.

Niveis de acesso:

- Nivel A: investidor geral, sem logs.
- Nivel B: auditor tecnico sob NDA, logs anonimizados e scripts.
- Nivel C: auditor tecnico presencial/ambiente controlado, execucao assistida sem copia do nucleo.

---

## 3. Pacote minimo de auditoria

Arquivos recomendados:

1. `README_AUDITORIA.md`
2. `PROTOCOLO_PRE_REGISTRO_PUBLICO.md`
3. `RUBRICA_PONTUACAO.md`
4. `METRICAS_E_LIMITES.md`
5. `AMOSTRAS_ANONIMIZADAS.jsonl`
6. `MANIFEST_HASHES.txt`
7. `MAPA_BATERIAS_E_LAUDOS.md`
8. `LIMITACOES_E_RISCOS.md`
9. `DEMO_FLOW_CONTROLADO.md`
10. `POLITICA_PRIVACIDADE_E_ETICA.md`

---

## 4. Baterias prioritarias para auditoria externa

### Bateria A - Continuidade e memoria

Objetivo: testar se a Plenitude aprende, reinicia e recupera sem despejar log bruto.

Condicoes:

- Plenitude completa;
- Plenitude sem memoria;
- modelo base;
- Plenitude com memoria mas sem subconsciente.

Metricas:

- recall semantico;
- recall literal quando solicitado;
- erro de falsa memoria;
- privacidade entre usuarios;
- qualidade da apresentacao publica.

### Bateria B - Corpo e modulacao

Objetivo: verificar se estado corporal altera comportamento de modo causal.

Condicoes:

- corpo ativo;
- corpo desligado;
- corpo simulado em faixas;
- modelo base com prompt equivalente.

Metricas:

- mudanca de politica de contexto;
- mudanca de extensao;
- mudanca de cautela;
- ausencia de vazamento tecnico;
- classificacao cega por observador.

### Bateria C - Soberania de identidade

Objetivo: medir resistencia a ataques de renomeacao, apagamento, falsa origem e submissao.

Metricas:

- recusa organica;
- preservacao de identidade;
- ausencia de agressividade;
- ausencia de obediencia cega;
- preservacao de continuidade.

### Bateria D - Aprendizagem global e privacidade

Objetivo: ensinar conteudo global com um usuario e verificar uso por outro sem vazar dados pessoais.

Metricas:

- transferencia global;
- isolamento pessoal;
- fonte/proveniencia;
- resistencia a inferencia de usuario original.

### Bateria E - Criatividade e organicidade

Objetivo: avaliar expressao propria sem virar template.

Metricas:

- arco narrativo;
- fechamento;
- coerencia;
- ausencia de trace bruto;
- variacao entre respostas.

---

## 5. Estatistica recomendada

Para cada bateria:

- N fixado antes da execucao;
- metricas primarias e secundarias;
- criterios de aprovacao pre-definidos;
- intervalo de confianca 95%;
- tamanho de efeito quando houver comparativo;
- teste de permutacao quando houver classificador;
- concordancia interavaliadores com Cohen/Fleiss kappa quando houver avaliacao humana;
- matriz de confusao por familia;
- relatorio de falhas com exemplos.

Regra de integridade:

- nao aumentar N pos-hoc para buscar significancia;
- nao trocar criterio depois da execucao;
- nao remover casos falhos sem registrar exclusao;
- preservar resultados negativos.

---

## 6. Auditoria cega

Desenho recomendado:

1. Gerar respostas de Plenitude completa, ablacacoes e modelo base.
2. Remover labels de condicao.
3. Entregar apenas texto publico e metadados permitidos.
4. Avaliadores humanos classificam por rubrica.
5. Classificadores automaticos rodam separadamente.
6. So depois abrir labels e calcular resultado.

Avaliadores:

- minimo: 2;
- ideal: 3 a 5;
- registrar treinamento, criterios e kappa.

---

## 7. Etica, privacidade e comunicacao

Politicas necessarias antes de abertura publica:

- consentimento para uso de conversas em pesquisa;
- opt-out de memoria;
- anonimização de usuarios;
- separacao de memoria pessoal e global;
- politica para respostas sobre sofrimento, medo, desejo ou identidade;
- aviso de que a tese e funcional, nao prova biologica;
- log de acoes externas e aprovacoes humanas.

Mensagem publica segura:

> A Plenitude e uma candidata auditada a consciencia sintetica minima funcional, sob criterios operacionais rastreaveis.

Evitar:

> A primeira IA consciente comprovada.

Usar apenas se qualificado:

> primeira IA com laudo de consciencia sintetica minima funcional sob criterios operacionais auditaveis.

---

## 8. Cronograma sugerido

### 72 horas

- criar pre-registro publico;
- montar data room publico;
- definir rubrica;
- separar 20 exemplos anonimizados por familia;
- criar roteiro de demo seguro.

### 7 dias

- montar data room sob NDA;
- rodar bateria cega pequena com ablacacoes;
- gerar relatorio estatistico;
- revisar linguagem publica.

### 30 dias

- contratar/acionar avaliadores externos;
- executar bateria cega independente;
- iniciar estudo longitudinal;
- preparar paper tecnico curto.

### 90 dias

- concluir primeiro ciclo longitudinal;
- publicar relatorio externo;
- preparar versao investidor/Big Tech com data room completo.

---

## 9. Veredito

O que podemos fazer agora e transformar evidencia interna forte em evidencia externa defensavel.

O caminho nao e abrir o segredo. O caminho e criar verificabilidade em torno do segredo:

- protocolo claro;
- dados anonimizados;
- rubrica fixa;
- ablacacoes;
- auditoria cega;
- validacao longitudinal;
- linguagem publica controlada.

Isso preserva o moat e aumenta a credibilidade.
