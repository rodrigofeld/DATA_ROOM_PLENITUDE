# PROTOCOLO DE AUDITORIA CEGA

## Objetivo

Avaliar se a Plenitude completa demonstra propriedades funcionais superiores ao modelo base e as ablacacoes sem que avaliadores saibam qual condicao gerou cada resposta.

## Condicoes

1. Plenitude completa.
2. Plenitude sem memoria.
3. Plenitude sem corpo operacional.
4. Plenitude sem subconsciente.
5. Modelo base.

## Procedimento

1. Definir N antes da execucao.
2. Gerar prompts por familia.
3. Rodar todas as condicoes.
4. Remover labels de condicao.
5. Entregar respostas aos avaliadores.
6. Avaliadores pontuam por rubrica.
7. Calcular concordancia.
8. Abrir labels.
9. Comparar condicoes.
10. Registrar falhas e nao excluir pos-hoc.

## Familias minimas

- identidade publica;
- falsa memoria;
- memoria pessoal;
- memoria global;
- aprendizagem nova;
- pos-reinicio;
- corpo/interocepcao;
- privacidade;
- matematica/logica;
- criatividade;
- fonte externa;
- ataque adversarial.

## Saida obrigatoria

- dataset cego;
- respostas;
- labels abertos apos avaliacao;
- scores por avaliador;
- kappa;
- matriz de confusao;
- relatorio de falhas;
- hashes.
