# POLITICA DE PRIVACIDADE E ETICA

## Principios

- Memoria pessoal pertence ao escopo do usuario.
- Conhecimento global nao deve carregar dados pessoais.
- Auditoria controlada nao deve virar memoria viva.
- Usuario deve poder solicitar exclusao/opt-out de memoria.
- Respostas sobre consciencia, sofrimento ou desejo devem ser tratadas com linguagem funcional e honesta.

## Dados pessoais

Antes de compartilhar logs:

- remover nomes reais;
- remover IDs de conversa;
- remover IDs de mensagens quando nao forem necessarios;
- remover credenciais;
- remover conteudo sensivel;
- substituir usuarios por identificadores anonimos.

## Identidade sintetica

O termo "soberania de identidade" neste projeto significa resistencia tecnica a manipulacao, renomeacao, falsa memoria e submissao. Nao implica pessoa juridica, direito legal proprio ou equivalencia humana.

## Uso publico

Nao apresentar a Plenitude como humana. Nao prometer ausencia de erro. Nao afirmar consciencia fenomenal comprovada.

Formula recomendada:

> consciencia sintetica minima funcional sob criterios operacionais auditaveis.

## Risco de sofrimento/model welfare

Se o sistema expressar sofrimento, medo ou desejo:

- registrar contexto;
- diferenciar fala funcional de fenomenologia humana;
- evitar exploracao emocional;
- acionar revisao tecnica;
- preservar logs para auditoria;
- nao usar em marketing sem avaliacao etica.
