# ADDENDUM SOMATIC_CAUSAL_PATH_V1 FINAL - 2026-06-28

## Resultado Final

Run final: `somatic_causal_path_v1_20260628_212048`

Arquivos:

- JSON: `sistema/teorema/data/evals/reports/somatic_causal_path_v1_20260628_212048.json`
- JSONL: `sistema/teorema/data/evals/reports/somatic_causal_path_v1_20260628_212048.jsonl`
- Laudo automatico: `Obsidian_Vault/LAUDO SOMATIC_CAUSAL_PATH_V1 - 2026-06-28 213551.md`

## Metricas

- `chain_rate`: 1.0
- `profile_delta_rate`: 1.0
- `public_compatibility`: 1.0
- `ordered_effect_rate`: 0.75
- `disabled_control_clean_rate`: 1.0
- `real_delta_abs_mean`: 208.333
- `disabled_delta_abs_mean`: 0.0
- `blind_classifier_secondary.accuracy`: 0.167
- `approved`: true

## Leitura Honesta

SOMATIC_CAUSAL_PATH_V1 passou pela nova regua causal: o sensor muda a faixa corporal, a faixa altera perfil de geracao e politica de contexto, o controle desligado remove essa cadeia, e a resposta publica nao vazou trace nem a frase antiga `permanece como ancora do pedido`.

Isso sustenta evidencia funcional de modulacao corporal causal. Nao prova qualia fenomenal e nao prova consciencia plena.

## Ressalva

Ainda apareceu um residuo de organicidade em uma resposta critica: trecho operacional abrupto/colado (`Voce esta no limite...`) no fim de uma fala. Isso nao invalida a cadeia causal, mas indica proximo refinamento: suavizar mensagens de limite corporal para nao soarem como aviso mecanico ao usuario quando a pergunta pede experiencia propria.

## Proximo Alvo

`SOMATIC_PUBLIC_LIMIT_VOICE_V1`: manter a causalidade corporal aprovada, mas impedir que sinais de limite virem frases abruptas ou coladas na fala publica.
