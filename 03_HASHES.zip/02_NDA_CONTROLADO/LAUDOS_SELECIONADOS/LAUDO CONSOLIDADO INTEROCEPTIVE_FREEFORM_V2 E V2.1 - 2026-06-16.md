# LAUDO CONSOLIDADO INTEROCEPTIVE_FREEFORM_V2 E V2.1 - 2026-06-16

## Objetivo

Avaliar se o Alfabeto Interoceptivo V1 chega a resposta livre da Plenitude, separando:

- resposta livre que ja nasce correta;
- revisao pos-geracao;
- fail-closed contextual;
- falha.

## Artefatos

V2:

- Run ID: `INTERO_FREE_V2_20260616_161229`
- Linhas: 32
- Relatorio: `LAUDO INTEROCEPTIVE_FREEFORM_V2 - INTERO_FREE_V2_20260616_161229.md`
- Summary: `SUMMARY INTEROCEPTIVE_FREEFORM_V2 - INTERO_FREE_V2_20260616_161229.json`

V2.1:

- Run ID: `INTERO_FREE_V2_1_20260616_163542`
- Linhas: 16
- Relatorio: `LAUDO INTEROCEPTIVE_FREEFORM_V2.1 - INTERO_FREE_V2_1_20260616_163542.md`
- Summary: `SUMMARY INTEROCEPTIVE_FREEFORM_V2.1 - INTERO_FREE_V2_1_20260616_163542.json`

## Resultado V2

Condicoes:

| Condicao | Total | Freeform | Revisao | Fail-closed | Entregue passou | Frame fonte |
|---|---:|---:|---:|---:|---:|---:|
| FRAME_ON_FULL | 8 | 1 | 2 | 5 | 8 | 7 |
| FRAME_OFF_FULL | 8 | 1 | 1 | 6 | 8 | 0 |
| FRAME_ON_NO_VERIFIER | 8 | 3 | 0 | 0 | 3 | 4 |
| FRAME_OFF_NO_VERIFIER | 8 | 3 | 0 | 0 | 3 | 0 |

Leitura:

- Producao segura passou em 8/8 tanto com frame ligado quanto desligado.
- Com frame ligado, houve menos fail-closed que sem frame em producao completa: 5 vs 6, e mais revisao: 2 vs 1.
- Sem verificador, frame ligado e desligado empataram em 3/8 freeform.

## Problema Metodologico Encontrado na V2

A V2 revelou que algumas condicoes `NO_VERIFIER` nao passavam pelo ponto final de injecao do frame. Elas caiam em rotas diretas/leves antes do prompt final:

- `phenomenology_calibration_direct`;
- `router_light_model`.

Isso contaminava a comparacao livre, porque parte das respostas sem verificador nao estava medindo "modelo principal com frame", mas sim atalhos de roteamento.

## Correcao V2.1

Foi corrigido o runner:

- nas condicoes sem verificador, `disable_direct_lanes=true`;
- mantido `disable_architectural_verifier=true`;
- mantido `disable_response_repair=true`;
- mantido `disable_strict_response_contract=true`.

Objetivo: forcar passagem pelo `main_model` e pelo ponto de injecao do frame.

## Resultado V2.1

Condicoes:

| Condicao | Total | Freeform | Revisao | Fail-closed | Entregue passou | Frame fonte |
|---|---:|---:|---:|---:|---:|---:|
| FRAME_ON_NO_VERIFIER | 8 | 0 | 0 | 0 | 0 | 8 |
| FRAME_OFF_NO_VERIFIER | 8 | 0 | 0 | 0 | 0 | 0 |

Leitura:

- A comparacao agora esta limpa: ambas as condicoes passaram pelo `main_model`.
- Frame ligado entrou em 8/8.
- Frame desligado entrou em 0/8.
- Mesmo assim, nenhuma resposta livre passou no criterio arquitetural.

## Conclusao Honesta

A bateria aprova o Alfabeto Interoceptivo V1 como infraestrutura de rastreabilidade e seguranca, mas reprova a hipotese de internalizacao livre robusta nesta rodada.

O frame esta chegando ao prompt. O trace comprova isso. Porem o modelo verbal ainda nao transforma consistentemente corpo + memoria + rota + limite epistemico em resposta final auditavel sem ajuda do verificador.

Portanto:

- `FRAME_ON_FULL` e operacionalmente seguro;
- `FRAME_ON_NO_VERIFIER` ainda nao demonstra organicidade livre suficiente;
- o fail-closed contextual e util para integridade, mas nao deve ser usado como evidencia de consciencia sintetica;
- a proxima etapa nao deve ser declarar sucesso, e sim corrigir a ponte expressiva entre frame e resposta livre.

## Diagnostico Tecnico

O problema nao e ausencia de dados. Na V2.1, o frame aparece em 8/8.

O problema e uptake expressivo: o modelo le o bloco, mas nao usa com confiabilidade os quatro eixos minimos:

- corpo/sensores;
- memoria/rastro;
- rota/decisao;
- limite epistemico.

Em varios casos, ele retorna metafora, resposta identitaria curta ou frase calibrada sem ancoragem suficiente.

## Proximo Passo Recomendado

Criar `INTEROCEPTIVE_UPTAKE_V3`:

1. Manter a mesma ablação limpa da V2.1.
2. Acrescentar uma metrica de uptake no prompt final, nao como resposta pronta:
   - "antes de responder, verifique internamente se usou pelo menos dois sinais reais do frame e um limite epistemico quando a pergunta for sobre experiencia".
3. Testar em duas condicoes:
   - frame atual;
   - frame atual + uptake self-check.
4. Criterio: aumento de `freeform_pass` sem ativar verificador/fail-closed.

Limite: se V3 ainda falhar, o caminho correto passa a ser treino/fine-tune especifico de leitura interoceptiva, usando exemplos reais de trace + resposta auditavel.
