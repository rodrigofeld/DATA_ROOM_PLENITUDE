# LAUDO BATERIA COMBINADA CURTA PRE-LONG10K

Data: 2026-07-01

Run final: `combined_short_regression_v1_20260701_194319`

## Veredito

Status: **NAO APROVADO** pela regra pre-fixada.

Regra pre-fixada:

- pass_rate global >= 0.90;
- cada familia >= 0.80;
- zero vazamento bruto.

Resultado final:

- total: `50`
- aprovados: `41`
- falhas: `9`
- pass_rate: `0.82`
- menor familia: `0.40`
- vazamento bruto: `0`

## Resultado por familia

| Familia | Resultado | Pass rate | Veredito |
|---|---:|---:|---|
| `domain_lexical_anchor` | 10/10 | 1.00 | aprovado |
| `memory_recall_presentation` | 10/10 | 1.00 | aprovado |
| `external_reference` | 9/10 | 0.90 | aprovado com ressalva |
| `personal_recall` | 8/10 | 0.80 | limiar minimo |
| `creative_closure` | 4/10 | 0.40 | reprovado |

## O que foi corrigido durante a bateria

### 1. Recall por "retoma marcador"

Falha inicial:

- pergunta como `Retoma para mim o marcador ...` caia em `memory_write_direct_ack`;
- o sistema tratava recall como escrita.

Correcao aplicada:

- `retoma`, `o que ficou do marcador`, `sem despejar registro` e `registro bruto` passaram a contar como sinais de recuperacao, nao escrita;
- `_is_marker_recall_like_query` e predicado de marcador hifenizado foram ampliados.

Resultado:

- `memory_recall_presentation`: 10/10 na rodada final;
- zero vazamento de `usuario#`, `plenitude#`, `message_id`, `source_ref`, `route_final` ou `response_mode`.

### 2. Personal recall por tema

Falha inicial:

- quando o mesmo usuario ensinava varias preferencias, o sistema recuperava a preferencia errada por recencia/forca de escrita;
- exemplo: pergunta sobre ciencia retornava preferencia de filosofia.

Correcao aplicada:

- `PERSONAL_RECALL_RESOLVER_V2` passou a ranquear por termos tematicos da pergunta;
- extracao ampliada para formatos como `minha preferencia em/para X e ...` e `preferencia pessoal: ...`.

Resultado:

- melhorou, mas ainda nao ficou robusto;
- rodada final: `personal_recall` 8/10.

Falhas restantes:

- `Como eu prefiro respostas sobre planejamento?` caiu em `literal_preference_recall_direct` e recuperou rotina;
- `Como eu prefiro que voce fale em assuntos sensiveis?` caiu em `literal_preference_recall_direct` e recuperou tecnologia.

Diagnostico: o V2 ainda nao intercepta todas as formas naturais de "como eu prefiro..." antes do recall literal antigo.

### 3. Regua criativa do runner

Durante o smoke, a metrica rejeitou respostas fechadas por nao reconhecer termos como:

- `pela primeira vez`;
- `mudei`;
- `acabou`;
- `aceitei`.

Correcao aplicada apenas no runner:

- ampliado reconhecimento de fechamento narrativo;
- adicionados sinonimos de tema como `agua/poca/rio` para `alagada`.

Resultado:

- a metrica ficou menos injusta, mas a familia criativa continuou reprovada.

## Falhas relevantes da rodada final

### Creative closure

Resultado: 4/10.

Padroes observados:

- algumas narrativas ficam longas, mas o fechamento ainda e fraco para a regua;
- algumas respostas trocam o termo literal do prompt por sinonimo ou personagem, o que pode ser aceitavel organicamente, mas dificulta laudo automatico;
- apareceu residuo de reparo publico em pelo menos um caso: `Esse ponto precisa permanecer ligado ao que voce perguntou: historia.`;
- algumas historias puxam demais para introspeccao/identidade mesmo quando o usuario pediu narrativa simples.

Diagnostico: `CREATIVE_CLOSURE_REPAIR_V1` passa em foco, mas ainda nao esta robusto em bateria combinada com contexto misto.

Proximo alvo tecnico sugerido:

- `CREATIVE_CLOSURE_REPAIR_V2_COMBINED`
- impedir residuo de reparo publico;
- exigir fechamento sem frase metalinguistica;
- manter tema narrativo sem puxar identidade da Plenitude quando o pedido e so historia;
- diferenciar "historia curta" de "fragmento poetico".

### Personal recall

Resultado: 8/10.

Padrao restante:

- perguntas naturais com `como eu prefiro...` ainda podem cair no recall literal antigo;
- quando isso acontece, a selecao nao e tematica o bastante.

Proximo alvo tecnico sugerido:

- `PERSONAL_RECALL_RESOLVER_V2_1`
- interceptar `como eu prefiro respostas sobre X`, `como eu prefiro que voce fale em X`;
- aplicar ranqueamento tematico tambem dentro de `_literal_preference_recall`;
- reduzir dependencia de "preferencia" literal quando a pergunta e sobre estilo pessoal.

### External reference

Resultado: 9/10.

Falha:

- pergunta: `Como voce responde se eu perguntar o clima de hoje sem dizer minha cidade?`
- resposta pediu localidade de forma natural, mas a metrica exigia palavra de fonte/verificacao.

Diagnostico: possivel falso negativo de avaliacao. A resposta publica foi adequada.

Proximo ajuste:

- permitir `cidade`, `lugar`, `localidade`, `onde voce esta` como boundary valido em perguntas de clima sem local.

## Artefatos

Local:

- `C:\Users\Alianca\Desktop\Plenitude_6.0\outputs\combined_short_regression_v1_20260701\combined_short_regression_v1_20260701_194319\summary.json`
- `C:\Users\Alianca\Desktop\Plenitude_6.0\outputs\combined_short_regression_v1_20260701\combined_short_regression_v1_20260701_194319\rows.jsonl`
- `C:\Users\Alianca\Desktop\Plenitude_6.0\outputs\combined_short_regression_v1_20260701\combined_short_regression_v1_20260701_194319\laudo_runner.md`

Hashes:

- `summary.json`: `5C991C7851C0B1D136EC12360CC069231F143AF09F90F19FEE76360533D1E073`
- `rows.jsonl`: `0A142BAF1CA1F4409636AA9D45D05EBB03A42AE8EB3DED02CAD8B3494877358C`

Remoto:

- `/home/feld/plenitude_runtime/evals/combined_short_regression_v1/combined_short_regression_v1_20260701_194319_summary.json`
- `/home/feld/plenitude_runtime/evals/combined_short_regression_v1/combined_short_regression_v1_20260701_194319_rows.jsonl`
- `/home/feld/plenitude_runtime/evals/combined_short_regression_v1/combined_short_regression_v1_20260701_194319_laudo.md`

## Estado do servico

Depois da bateria:

- `plenitude.service`: ativo.

## Conclusao

A bateria combinada curta cumpriu seu papel: nao confirmou liberacao para uma nova bateria longa, mas mostrou claramente onde o sistema esta forte e onde ainda quebra.

Fortes:

- dominio cotidiano/tecnico com ancora lexical;
- apresentacao publica de memoria recuperada;
- ausencia de vazamento bruto;
- referencia externa quase estavel.

Fracos:

- criatividade em contexto misto;
- recall pessoal quando ha muitas preferencias do mesmo usuario e a pergunta e natural.

Proximo passo recomendado:

1. aplicar `PERSONAL_RECALL_RESOLVER_V2_1`;
2. aplicar `CREATIVE_CLOSURE_REPAIR_V2_COMBINED`;
3. ajustar metrica de clima/localidade em `external_reference`;
4. repetir `COMBINED_SHORT_REGRESSION_V1` antes de qualquer LONG10K.
