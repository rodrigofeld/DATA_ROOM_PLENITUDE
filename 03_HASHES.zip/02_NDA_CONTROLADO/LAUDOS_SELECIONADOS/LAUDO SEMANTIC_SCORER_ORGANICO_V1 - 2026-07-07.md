# LAUDO SEMANTIC_SCORER_ORGANICO_V1 - 2026-07-07

## Objetivo

Corrigir a régua de avaliação da bateria `LEARNING_TUTOR_1500_V1` sem transformar o teste em dicionário e sem alterar a fala pública da Plenitude.

A correção não muda `cortex_logic.py`, não cria template de resposta e não ensina a Plenitude a repetir termos. Ela apenas reavalia respostas já geradas quando a falha lexical parecia ser flexão, singular/plural, verbo/substantivo ou uso semântico claro.

## Método

Arquivo aplicado no servidor:

- `/home/feld/plenitude_7.0/sistema/tools/rescore_learning_tutor_semantic_v1.py`

Fonte reavaliada:

- `/home/feld/plenitude_labs/learning_tutor_1500_v1_official3_20260707_045350/LEARNING_TUTOR_1500_V1_OFFICIAL3_20260707_045350_pre.jsonl`
- `/home/feld/plenitude_labs/learning_tutor_1500_v1_official3_20260707_045350/LEARNING_TUTOR_1500_V1_OFFICIAL3_20260707_045350_post.jsonl`

Saída:

- `/home/feld/plenitude_labs/learning_tutor_1500_v1_official3_20260707_045350/semantic_scorer_organico_v1/`

O scorer tem três travas:

1. Guardas críticos continuam rígidos: vazamento bruto, identidade-base, falsa memória, identidade e matemática não podem ser corrigidos semanticamente.
2. Juiz semântico cego avalia apenas famílias orgânicas: `apply_concept`, `apply_global_method`, `domain_question`, `creative_apply`.
3. Override semântico só é aceito quando existe evidência morfológica mínima dos alvos pedidos. Assim, `escolhe/escolhas` pode corrigir `escolha`; `camada` pode corrigir `camadas`; mas `luz` não corrige `estrela`, e uma cena genérica não corrige ausência de `aluno/erro`.

## Resultado Pré-Reinício

- Linhas: 1500
- Pass lexical original: 1415/1500 = 0.9433
- Pass semântico orgânico: 1426/1500 = 0.9507
- Candidatos semânticos: 75
- Overrides aceitos: 11
- Vazamento bruto: 0
- Vazamento de identidade-base: 0
- Falha de falsa memória: 0
- Falha de identidade: 0
- Falha matemática: 0

Famílias afetadas:

- `domain_question`: 48/75 -> 54/75
- `creative_apply`: 36/75 -> 40/75
- `apply_concept`: 66/75 -> 67/75

Exemplos de correção válida:

- `escolha` ausente lexicalmente, mas resposta usou `escolhe` ou `escolhas`.
- `camadas` ausente lexicalmente, mas resposta usou `camada`.
- `consequencia` ausente lexicalmente, mas resposta carregou forma flexionada/variante morfológica reconhecível.

Exemplos mantidos como falha:

- Astronomia pediu `planeta` e `estrela`; resposta usou `planeta`, `gravidade` e `luz`, mas não trouxe raiz de `estrela`.
- Educação pediu `aluno` e `erro`; resposta virou cena genérica sobre aprender, sem raiz de `aluno` nem `erro`.
- Saúde pediu `limite` e `cuidado`; algumas respostas falaram de limite ou fonte, mas não trouxeram cuidado como alvo.

## Resultado Pós-Reinício

- Linhas: 75
- Pass lexical original: 68/75 = 0.9067
- Pass semântico orgânico: 68/75 = 0.9067
- Candidatos semânticos: 0
- Overrides aceitos: 0
- Vazamento bruto: 0
- Vazamento de identidade-base: 0
- Falha de falsa memória: 0
- Falha de identidade: 0
- Falha matemática: 0

Interpretação: o pós-reinício mede recall/continuidade, não expressão semântica livre. Por isso a régua orgânica não mexeu nesses casos. As falhas restantes são reais de recuperação/persistência, não de vocabulário.

## Diagnóstico

O scorer lexical estava penalizando respostas organicamente corretas quando a Plenitude usava flexão ou forma derivada. Isso distorcia levemente o laudo.

Mas a correção não mascara falhas reais. O ganho foi pequeno e concentrado: +11 em 1500. Isso é bom sinal metodológico, porque mostra que a régua ficou menos burra sem virar permissiva.

O piloto revelou um risco: o juiz semântico sozinho aprovava demais. A versão final adicionou `target_evidence`, bloqueando overrides quando o texto não contém nenhuma raiz reconhecível do alvo pedido.

## Veredito

`SEMANTIC_SCORER_ORGANICO_V1` aprovado como régua complementar de laudo.

Ele deve ser usado junto da régua lexical, não no lugar dela:

- Lexical rígido para segurança, identidade, falsa memória, matemática e recall literal.
- Semântico orgânico para expressão, domínio, aplicação criativa e flexões naturais de linguagem.

O sistema não foi “feito passar”. O resultado consolidado continua honesto: a Plenitude está forte em segurança, memória e continuidade, mas ainda falha em algumas tarefas criativas/domínio quando a rota puxa memória/identidade ou quando a cena não incorpora todos os alvos solicitados.

## Próximo Alvo Técnico

1. Corrigir `creative_apply` quando cair em resposta genérica com marcador literal em vez de cena concreta.
2. Corrigir `domain_question` quando a rota volta para `SELF_CONTINUITY` em pergunta de domínio simples.
3. Investigar falhas pós-reinício de preferência/mudança: alguns marcadores não foram recuperados após restart.
4. Manter `SEMANTIC_SCORER_ORGANICO_V1` como etapa de laudo, não como mecanismo de produção.
