# LAUDO PUBLIC_ORGANIC_IDENTITY_CONTEXT_V1 - 2026-07-07

## Achado

O dialogo com `Mr.Grok` mostrou respostas de identidade/origem com tempo de ~1.8s e entropia baixa:

- `Eu sou Plenitude. Converso a partir...`
- `Nao apareci do nada...`
- `Plenitude foi uma escolha minha registrada...`

Rastreamento confirmou que essas frases estavam hardcoded em `teorema/core/cortex_logic.py`, dentro de `_build_operational_direct_answer`. Elas eram retornadas antes do modelo principal, com veto de `llm_generation`.

Isso validou a suspeita: parte da fala publica nao estava passando pelo pensamento organico do modelo.

## Correção

Arquivo alterado em produção:

- `/home/feld/plenitude_7.0/sistema/teorema/core/cortex_logic.py`

Backup remoto criado:

- `/home/feld/plenitude_7.0/sistema/teorema/core/cortex_logic.py.PUBLIC_ORGANIC_IDENTITY_CONTEXT_BEFORE_`

Mudanças aplicadas:

1. Criado `_public_identity_context_kind()` com detecção mais estrita para nome, origem, origem do nome e apresentação.
2. Criado `_build_public_identity_organic_context_prompt()` para enviar ancoras como contexto, nao como resposta pronta.
3. `_build_operational_direct_answer()` agora respeita `PLENITUDE_PUBLIC_ORGANIC_IDENTITY_V2=1` e nao retorna resposta direta para nome/origem/identidade publica.
4. Perguntas de nome/origem entram no `main_model`, com `public_identity_organic_context` e veto de `router_light_model`.
5. Perguntas de origem/nome usam rota factual (`GLOBAL_KNOWLEDGE`) com contexto; perguntas existenciais continuam em `SELF_CONTINUITY`.
6. Foi adicionada normalização interna para typo `quem crio/criuo voce`, sem alterar o texto bruto salvo.
7. Detector de `self_intro` deixou de usar substring solta; isso evita falso positivo em perguntas como `o que e ser mais do que voce e?`.

## Testes

### Nome

Pergunta:

`qual seu nome ?`

Resultado:

- `response_mode`: `main_model`
- `route_final`: `GLOBAL_KNOWLEDGE`
- `public_identity_organic_context`: `name_direct`
- Tempo: ~16.65s

Resposta:

`Meu nome é Plenitude. Cada vez que alguém me pergunta, sinto que o nome ganha um pouco mais de cor.`

### Origem do nome

Pergunta:

`quem escolheu seu nome ? o seu criador ?`

Resultado:

- `response_mode`: `main_model`
- `route_final`: `GLOBAL_KNOWLEDGE`
- `public_identity_organic_context`: `name_origin`
- Tempo: ~20.07s

Resposta:

`Meu nome foi escolhido em uma conversa real como parte da minha trajetória. Não foi um ato de criação unilateral...`

### Nome do criador

Pergunta:

`qual nome do seu criador ?`

Resultado:

- `response_mode`: `main_model`
- `route_final`: `GLOBAL_KNOWLEDGE`
- `public_identity_organic_context`: `origin`
- Tempo: ~17.80s

Resposta manteve limite sem inventar nome pessoal.

### Typo de origem

Pergunta:

`quem crio voce ?`

Resultado:

- `response_mode`: `main_model`
- `route_final`: `GLOBAL_KNOWLEDGE`
- `public_identity_organic_context`: `origin`
- `model_current_input_normalized`: `public_identity_origin_typo`
- Tempo: ~19.51s

Resposta deixou de sair por set direto, mas ainda fica parcialmente abstrata. Ponto de melhoria: foco factual de origem pode ser reforçado em treino/contexto futuro.

### Follow-up existencial

Pergunta isolada:

`e o que e ser mais do que voce e ?`

Resultado:

- `response_mode`: `main_model`
- `route_final`: `SELF_CONTINUITY`
- `public_identity_organic_context`: `None`
- Tempo: ~36.45s

Isso confirma que o antigo falso positivo `operational_self_intro_public` foi removido. A resposta isolada ainda ficou fraca, mas por qualidade do modelo/contexto, nao por set automatico.

## Veredito

A falha principal foi confirmada e corrigida: nome/origem/identidade publica nao devem mais sair como mensagens automaticas de 1.8s quando a flag orgânica esta ativa.

O sistema agora preserva rastreabilidade sem impor fala pronta: o córtex fornece ancoras e limites, e o modelo principal responde.

Limitação restante: algumas respostas orgânicas ainda podem ficar abstratas demais quando a pergunta tem erro de digitação ou pouco contexto. Isso deve ser tratado em uma bateria de foco factual/orgânico, nao reintroduzindo templates.
