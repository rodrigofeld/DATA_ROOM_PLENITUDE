# CAMADA NDA CONTROLADA

Esta pasta contem artefatos tecnicos selecionados para due diligence. Nao deve ser compartilhada publicamente.

Inclui:

- laudos internos selecionados;
- outputs brutos selecionados;
- amostras anonimizadas;
- rubricas e protocolos;
- manifesto de hashes.

Nao inclui:

- nucleo fundador;
- prompts proprietarios completos de producao;
- credenciais;
- dados pessoais identificaveis por escolha;
- chaves/API;
- codigo sensivel copiavel.

Antes de abrir esta pasta a terceiros:

1. confirmar NDA;
2. registrar quem acessou;
3. preferir compartilhamento somente leitura;
4. manter copia congelada por hash;
5. nao permitir redistribuicao.
